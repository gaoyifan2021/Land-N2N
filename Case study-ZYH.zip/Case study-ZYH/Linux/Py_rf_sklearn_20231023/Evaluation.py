import numpy as np
from osgeo import gdal
import os
import time
import shutil

def ReadGeoASC(filepath):
    """ Read raster data in ASC format """

    dataset = gdal.Open(os.path.join(os.path.dirname(__file__),filepath))
    # print(dataset)
    im_width = dataset.RasterXSize  # Get the row of the data

    im_height = dataset.RasterYSize  # Get the col of the data
    #print(im_width, im_height)
    band = dataset.GetRasterBand(1)  # Get the band
    im_datas = band.ReadAsArray(0, 0, im_width, im_height)  # Get the data
    
    im_geotrans = dataset.GetGeoTransform()
    """
        xllcorner = im_geotrans[0]
        yllcorner = im_geotrans[3]
        cellsize = im_geotrans[1]
    """

    #print(im_geotrans)
    #print(im_geotrans)
    return [im_datas,im_geotrans]

def CalKappa(data_truth, data_simulation, fig_log):
    """
        这个函数用来计算Kappa系数
    """
    type_count = np.max([np.max(data_truth), np.max(data_simulation)]) + 1

    m = np.zeros(shape=(type_count,type_count))

    size = np.shape(data_truth)

    for i in range(size[0]):
        for j in range(size[1]):
            if data_truth[i,j] != -9999:
                m[int(data_truth[i,j]),int(data_simulation[i,j])] = m[int(data_truth[i,j]),int(data_simulation[i,j])] * 1 + 1

    m = m / np.sum(m)
    #print(m)
    po = 0
    pe = 0
    pp = 0
    for t in range(type_count):
        po = po + m[t,t]
        pe = pe + np.sum(m[t,:]) * np.sum(m[:,t])
        pp = pp + np.sum(m[:,t])
    #print(m)
    kappa = (po - pe) / (pp - pe)
    fig_log.write('The kappa is :' + str(kappa) + '\n')
    fig_log.write('___________________________' + '\n')

    return kappa

def CalFoM(data_start, data_truth, data_simulation, fig_log):
    
    fig_log.write('Land system' + '\t' + 'A' + '\t' + 'B' + '\t' + 'C' + '\t' + 'D' + '\t' + 'FoM' + '\n')
    
    type_count = np.max([np.max(data_start),np.max(data_truth), np.max(data_simulation)]) + 1

    size = np.shape(data_truth)

    # 计算每种土地系统类型的FoM
    result = np.zeros(shape=(type_count, 5))

    sign_simulation = np.zeros(shape=(type_count,size[0], size[1]))
    sign_start = np.zeros(shape=(type_count,size[0], size[1]))
    sign_ground = np.zeros(shape=(type_count,size[0], size[1]))
    for ls in range(type_count):
        # 找到每种类型的范围
        for i in range(size[0]):
            for j in range(size[1]):
                
                if data_start[i,j] != -9999:
                    if data_simulation[i,j] == ls:
                        sign_simulation[ls,i,j] = ls
                        sign_start[ls,i,j] = data_start[i,j] * 1
                        sign_ground[ls,i,j] = data_truth[i,j] * 1
                    else:
                        sign_simulation[ls,i,j] = -9999
                        sign_start[ls,i,j] = -9999
                        sign_ground[ls,i,j] = -9999
  
                else:
                    sign_simulation[ls,i,j] = -9999
                    sign_start[ls,i,j] = -9999
                    sign_ground[ls,i,j] = -9999

        for i in range(size[0]):
            for j in range(size[1]):
                if sign_start[ls, i,j] != -9999:
                    if  (sign_start[ls,i,j] != sign_ground[ls,i,j] ) and ( sign_start[ls,i,j] == sign_simulation[ls,i,j] ):
                        result[ls,0] = result[ls,0] * 1 + 1
                    if  (sign_start[ls,i,j] != sign_ground[ls,i,j] ) and ( sign_start[ls,i,j] != sign_simulation[ls,i,j] ) and (sign_simulation[ls,i,j] == sign_ground[ls,i,j]):
                        result[ls,1] = result[ls,1] * 1 + 1
                    if  (sign_start[ls,i,j] != sign_ground[ls,i,j] ) and ( sign_start[ls,i,j] != sign_simulation[ls,i,j] ) and (sign_simulation[ls,i,j] != sign_ground[ls,i,j]):
                        result[ls,2] = result[ls,2] * 1 + 1
                    if  (sign_start[ls,i,j] == sign_ground[ls,i,j] ) and ( sign_start[ls,i,j] != sign_simulation[ls,i,j] ):
                        result[ls,3] = result[ls,3] * 1 + 1
        #print(ls,result[ls,0],result[ls,1],result[ls,2] ,result[ls,3],result[ls,4] )
        if ( result[ls,0] + result[ls,1] + result[ls,2] + result[ls,3] ) != 0:
            result[ls,4] = result[ls,1] / ( result[ls,0] + result[ls,1] + result[ls,2] + result[ls,3] )
            fig_log.write(str(ls) + '\t' + str(result[ls,0]) + '\t' + str(result[ls,1]) + '\t' + str(result[ls,2]) + '\t' + str(result[ls,3]) + '\t' + str(result[ls,4]) + '\n')    
        else:
            fig_log.write(str(ls) + '\t' + ': There is no change cells.' + '\n')    

        
    
    # 计算整体的FoM
    FoM = np.sum(result[:,1]) / ( np.sum(result[:,0]) + np.sum(result[:,1]) + np.sum(result[:,2]) + np.sum(result[:,3]) )
    fig_log.write('FoM is : ' + str(FoM) + '\n')
    return FoM


# 复制文件到特定目录
oldname= 'Data/cov_all.1.asc'
newname = 'Evaluation/cov_all.1.asc'
shutil.copyfile(oldname,newname)

path_start = 'Evaluation/cov_all.0.asc'
path_simulation = 'Evaluation/cov_all.1.asc'
path_ground = 'Evaluation/actual.asc'


[data1, geo1] = ReadGeoASC(path_start)
[data2, geo2] = ReadGeoASC(path_simulation)
[data3, geo2] = ReadGeoASC(path_ground)

fig_log = open(os.path.join(os.path.dirname(__file__),'Evaluation/log.fil'), 'w')
fig_log.write('Start of simulation at: ')
fig_log.write(str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())))
fig_log.write('\n')

Kappa = CalKappa(data3, data2, fig_log)
FoM = CalFoM(data1, data3, data2, fig_log)

#print(Kappa, FoM)