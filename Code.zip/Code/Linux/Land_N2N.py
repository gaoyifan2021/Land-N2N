import os
import sys

a = eval(sys.argv[1])
b = eval(sys.argv[2])

if a == 1:
    os.system("python Suitability.py")

os.system("python main_v20231025.py")
if b == 1:
    
    os.system("python Evaluation.py")