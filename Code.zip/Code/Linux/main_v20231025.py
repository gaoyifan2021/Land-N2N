import os
import numpy as np
from osgeo import gdal
import time
import re
import sys

def ReadGeoASC(filepath):
    """ Read raster data in ASC format """

    dataset = gdal.Open(os.path.join(os.path.dirname(__file__),filepath))
    # print(dataset)
    im_width = dataset.RasterXSize  # Get the row of the data

    im_height = dataset.RasterYSize  # Get the col of the data
    #print(im_width, im_height)
    band = dataset.GetRasterBand(1)  # Get the band
    im_datas = band.ReadAsArray(0, 0, im_width, im_height)  # Get the data
    
    im_geotrans = dataset.GetGeoTransform()
    """
        xllcorner = im_geotrans[0]
        yllcorner = im_geotrans[3]
        cellsize = im_geotrans[1]
    """

    #print(im_geotrans)
    #print(im_geotrans)
    return [im_datas,im_geotrans]

def ReadMainParameters(filepath, fig):
    """读取main 文件里面的参数"""
    
    f = open(filepath)               # 返回一个文件对象 
    lines = f.readlines()
    res = re.split('\t| |\n',lines[0])
    weight = re.split('\t| |\n',lines[1])
    condition = re.split('\t| |\n',lines[2])
    Seed = re.split('\t| |\n',lines[3])
    Step = re.split('\t| |\n',lines[4])
    myloop = re.split('\t| |\n',lines[5])
    flag = re.split('\t| |\n',lines[6])
    max_loop = re.split('\t| |\n',lines[7])
    f.close()

    while '' in res:
        res.remove('')
    while '' in weight:
        weight.remove('')
    while '' in condition:
        condition.remove('')
    while '' in Seed:
        Seed.remove('')
    while '' in Step:
        Step.remove('')
    while '' in myloop:
        myloop.remove('')
    while '' in flag:
        flag.remove('')
    while '' in max_loop:
        max_loop.remove('')

    fig.write('The resistance of land types:' + str(res) + '\n')
    fig.write('The weight of each demand: ' + str(weight) + '\n')
    if condition[0] == 0:
        fig.write('The average difference between stopping iterations:' + str(condition[1]) + '\n')
        fig.write('The max difference between stopping iterations:' + str(condition[2]) + '\n')
    if condition[0] == 1:
        for dd in range(len(weight)):
            fig.write( 'If the difference of teh demand ' + str(dd) + ' is less than ' + str(condition[1 + dd]) + ', the simulation success.')
    fig.write('The seed of simulation is :' + str(Seed) + '\n')
    fig.write('The step of simulation is :' + str(Step) + '\n')
    fig.write('The loop of iteration :' + str(myloop) + '\n')
    if flag == 1:
        fig.write('Enable more granular iteration.' + '\n')
    else:
        fig.write('Not enable more granular iteration.' + '\n')
    fig.write('The max loop is :' + str(max_loop) + '\n')
    fig.flush()

    return [list(map(float, res)), list(map(float, weight)), list(map(float, condition)), float(Seed[0]), float(Step[0]),  int(myloop[0]), int(flag[0]), int(max_loop[0])]

def checkASCData(filepath,fig):
    files= os.listdir(filepath) #得到文件夹下的所有文件名称

    # 找到驱动因子
    df_list = []
    for file in files:
        if (os.path.splitext(file)[1] == '.asc') & (file[0] == 's'):
            df_list.append(file)
    df = []
    fig.write('The number of driving factors :'+ str(len(df_list)) + '\n')
    xllcorner = []
    yllcorner = []
    cellsize = []
    for i in range(0, len(df_list)):
        [data, geotrans] = ReadGeoASC(filepath+"/"+"sc1gr"+str(i)+".fil.asc")  #打开文件
        df.append(data)
        xllcorner.append(geotrans[0])
        yllcorner.append(geotrans[3])
        cellsize.append(geotrans[1])
        #print(df,xllcorner,yllcorner,cellsize)    
        #print(df[0][1,1])

    [cov, geotrans] = ReadGeoASC(filepath+"/"+"cov_all.0.asc")
    size = np.shape(cov)
    cov_list = []  # 储存土地类型的编号
    for i in range(0, np.max(cov)+1):
        # 被这个左开右闭气死了啊！
        if np.sum(cov == i) != 0:
            cov_list.append(i)

    xllcorner.append(geotrans[0])  
    yllcorner.append(geotrans[3]) # 这个是左上角的纵坐标，我们应该计算的是左下角的纵坐标
    cellsize.append(geotrans[1])

    [region, geotrans] = ReadGeoASC(filepath+"/"+"cov_all.0.asc")

    xllcorner.append(geotrans[0])
    yllcorner.append(geotrans[3])
    cellsize.append(geotrans[1])

    flag = 0
    for i in range(0,len(xllcorner)):
        if (xllcorner[0] == xllcorner[i]) & (yllcorner[0] == yllcorner[i]) & (cellsize[0] == cellsize[i]):
            flag = flag + 0
        else:
            flag = flag + 1

    if flag == 0:
        fig.write('Check: The raster data have the same extent.' + '\n') 
        fig.write('The row of data :' + str(size[0]) + '\n')
        fig.write('The col of data :' + str(size[1]) + '\n')   
        fig.write('The xllcorner of data :' + str(xllcorner[0]) + '\n') 
        fig.write('The yllcorner of data :' + str(yllcorner[0]) + '\n') 
        fig.write('The cellsize of data :' + str(cellsize[0]) + '\n')
        fig.write('The number of land type :' + str(len(cov_list)) + '\n')
        fig.write('The land types are :' + str(cov_list) + '\n')

    else:
        fig.write('Check: The raster data have not the same extent.'+ '\n')
        fig.write('Exit.' + '\n')

    fig.flush()
    return [cov, cov_list, region, df, xllcorner, yllcorner, cellsize]

def ReadDemand(filepath,fig):
    data = np.loadtxt(filepath)
    size = np.shape(data)
    if len(size) == 1:
        fig.write('Simulation year: ' + str(len(size) - 1 ) + '\n')
        fig.flush()
        return [data, len(size)]
        #fig.write('The number of demand: ' + str(1) + '\n')
    else:
        fig.write('Simulation year: ' + str(size[0] - 1) + '\n')
        fig.flush()
        #fig.write('The number of demand: ' + str(size[1]) + '\n')
        return [data, size[0]]
    

def ReadCapacity(filepath):
    """
        这个函数的功能是读取供给能力
    """
    data = np.loadtxt(filepath)
    return data

def ReadAllow(filepath):
    """
    这个函数的功能是读取转移矩阵，并将不允许转换的0，改为负无穷
    """
    data = np.loadtxt(filepath)
    #data[data == 0] = float('-inf')  ## 将allow中等于0的地方替换为负无穷
    return data

def ReadNeighbor(filepath, count,fig):
    """
        读取邻域方程，第一行是权重，第二行是邻域大小，第二行至第n行是系数，最后一行是常数项
    """
    data = np.loadtxt(filepath)
    nei_weight = data[0,:] 
    nei_size = data[1,:]
    nei_coefficient = data[2:count+2,:]
    nei_constant = data[-1,:]
    #fig.write("The weight of neighborhood :" + nei_weight + '\n')
    #fig.flush()
    #print(nei_weight, nei_size, nei_coefficient, nei_constant)

    return [nei_weight, nei_size, nei_coefficient, nei_constant]

def CalNeighbor(start, neigh_weight, nei_size, nei_coefficient, nei_constant):
    
    """
        这个函数用来计算邻域效应的结果，这个函数应该在每一年结束的时候更新一次
        start 表示的是输入的土地数据
        neigh_weight 表示的是权重
        nei_size 表示的是邻域窗口的大小
        nei_coefficient 表示的是邻域方程的系数
        nei_constant 表示的邻域方程的常数项

        size 是每一个类型都有一个，所以这个函数需要重新写
    """
    size = np.shape(start)
    #print(start)
    
    result = []
    new_row = np.zeros(shape=len(nei_size))
    new_col = np.zeros(shape=len(nei_size))

    max_nei_size = np.max(nei_size)

    # 按照最大邻域来扩充矩阵

    new_row = size[0] + 2 * int(max_nei_size)
    new_col = size[1] + 2 * int(max_nei_size)

   
    # 将start数据按照最大邻域边界扩展一下
        
    new_start = np.zeros(shape=(new_row, new_col)) 
    new_start[new_start == 0] = -9999 # 在这里已经都替换成-9999了
    for r in range(int(max_nei_size), size[0] + int(max_nei_size)):
        for c in range(int(max_nei_size), size[1] + int(max_nei_size)):
            new_start[r,c] = start[r - int(max_nei_size), c - int(max_nei_size)]
    #print(new_start)
    # 计算有几种邻域的大小
    new_size_type = len(np.unique(nei_size))
    #print(new_size_type)

    if new_size_type == 1:
        """
            如果只存在一种邻域大小的话，那么所有类型的邻域效应可以一起计算
        """
        R = np.zeros(shape=(len(nei_size),new_row, new_col))

        # 计算填充的变量
        temp_9999 = np.zeros(shape=len(nei_size))
        temp_9999[temp_9999 == 0] = -9999
        
        for r in range(int(max_nei_size), size[0] + int(max_nei_size)):
            for c in range(int(max_nei_size), size[1] + int(max_nei_size)):
                if new_start[r,c] != -9999:
                    #print(r,c)
                    # 找到邻域范围内的数据, 这个同样是左边是闭区间，右边是开区间
                    #temp = []
                    temp = new_start [r-int(max_nei_size):r+int(max_nei_size) + 1,c-int(max_nei_size):c+int(max_nei_size)+ 1] * 1
                    # 修改切片结果时，原数组的元素也会被修改
                    # 去掉邻域中心的数据
                    #print(int(max_nei_size),int(max_nei_size))
                    #print(temp,temp[1,1])
                    #temp[(temp.size[0]-1)/2 , (temp.size[1]-1)/2] = -9999
                    temp[int(max_nei_size), int(max_nei_size)] = -9999
                    #print(temp)
                    #print(np.shape(temp))
                    # 计算邻域内每种土地类型的占比
                    p = np.zeros(shape=len(neigh_weight))
                    for k in range(0, len(neigh_weight)):
                        #print(np.sum(temp == k))
                        p[k] = float(np.sum(temp == k)) / float(((2 * int(max_nei_size) + 1) * (2 * int(max_nei_size) + 1) - 1))
                    #print(p)
                    # 按照邻域方程来计算邻域效应
                    n = np.zeros(shape=len(neigh_weight))
                    for k in range(0, len(neigh_weight)):
                        #print(nei_coefficient[:,k],p)
                        n[k] = neigh_weight[k] * (np.dot(nei_coefficient[:,k],p)) + nei_constant[k]
                    
                    R[:,r,c] = n # 这个变量还没有去掉邻域的边
                else:
                    R[:,r,c] = temp_9999
    else:
        """
            如果存在多个邻域大小的话，就需要每种类型分开来计算，这样计算过程会慢一些
        """
        for r in range(int(max_nei_size), size[0] - int(max_nei_size)):
            for c in range(int(max_nei_size), size[1] - int(max_nei_size)):
                if new_start[r,c] != -9999:
                    for t in range(0, len(nei_size)):
                        
                        # 找到邻域范围内的数据
                        temp = new_start [r-int(max_nei_size):r+int(max_nei_size) + 1,c-int(max_nei_size):c+int(max_nei_size)+ 1] * 1
                        #print('qiguai ')
                        # 去掉邻域中心的数据
                        temp[int(nei_size[t]),int(nei_size[t])] = -9999

                        # 计算邻域内每种土地类型的占比
                        p = np.zeros(shape=len(neigh_weight))
                        for k in range(0, len(neigh_weight)):
                            p[k] = np.sum(temp == k) / ((2 * int(max_nei_size) + 1) * (2 * int(max_nei_size) + 1) - 1)

                        # 按照邻域方程来计算邻域效应
                        n = neigh_weight[t] * (np.dot(nei_coefficient[:,t],p)) + nei_constant[t]

                        R[t,r,c] = n
                else:
                    R[:,r,c] = temp_9999

    # 缩减矩阵

    result = R[:, int(max_nei_size):new_row - int(max_nei_size),int(max_nei_size):new_col - int(max_nei_size)] * 1
    #print(result)
   
    return result

def ReadProb(count,row,col,fig):
    """读取Prob的结果"""
    result = np.zeros(shape=(count,row,col))
    for i in range(0, count):
        [result[i,:,:], geo] = ReadGeoASC(os.path.join(os.path.dirname(__file__),'Data','prob1_'+str(i)+'.1.asc'))
        #print(data)
        
    #fig.write('The count of teh probabilistic surface: ' + str(count) +  '\n')
    #fig.flush()
    return result

def iter(cov, index1, index2, cov_list, lusmatrix, res, intertia, demand, prob, nei, allow, weight):
    """
        计算一次迭代发生的变化
        变量解释：
        cov: 本次迭代中输入的土地数据
        index1: 土地数据中非 -9998 和 非 -9999 的位置，行坐标
        index2: 土地数据中非 -9998 和 非 -9999 的位置，列坐标
        cov_list: 土地类型的编号列表
        lusmatrix: 供给能力
        res: 转换阻力值
        demand: 下一次迭代的需求
        prob: 回归的结果
        nei: 邻域的结果
        allow: 是否允许转换
        loop: 多少次迭代之后开启逐步迭代
        region:限制区域
        如果在逐步迭代的次数之内的话, 整个区域迭代一次返回一次结果
    """
    #size = np.shape(cov)
    cov_new = cov * 1 # cov_new 的初值先定义为上一次迭代的结果

    # 在迭代之前就计算好竞争优势
    count_type = len(cov_list)

    # 定义一个矩阵存储竞争优势
    sumelas = np.zeros(shape =(count_type,count_type))

    for old_type in range(0, count_type):
        for new_type in range(0, count_type):
            for d in range(0, len(demand)):
                sumelas[old_type,new_type] = sumelas[old_type,new_type] + weight[d] * intertia[d] * ((lusmatrix[new_type][d] - lusmatrix[old_type,d]) / np.sum(lusmatrix[:,d]))

    # 顺便定义一个矩阵来存储转换阻力值
    res_m = np.zeros(shape =(count_type,count_type))

    for tt in range(0, count_type):
        res_m[tt][tt] = res[tt]

    count_cell = len(index1)
    #print(count_cell)
    #print(np.shape(prob))
    #print(np.shape(sumelas))
    #print(np.shape(res_m))
    #print(np.shape(nei))
    tempmax = np.zeros(shape = (count_cell, count_type))

    for i in range(0, count_cell):
        # 进行迭代
        #print(prob[:,index1[i],index2[i]])
        #print(sumelas[int(cov[index1[i]][index2[i]]),:])
        #print(res_m[int(cov[index1[i]][index2[i]]),:])
        #print(nei[:,index1[i],index2[i]])
        #print(allow[int(cov[index1[i]][index2[i]]),:])
        #print(index1[i],index2[i])
        tempmax[i,:] =  prob[:,index1[i],index2[i]] + sumelas[int(cov[index1[i],index2[i]]),:] + res_m[int(cov[index1[i],index2[i]]),:] + nei[:,index1[i],index2[i]] 
        
        for qq in range(count_type):
            if allow[int(cov[index1[i],index2[i]]),qq] == 0:
                tempmax[i,qq] = float('-inf')


        #print(int(cov[index1[i],index2[i]]))
        #print(prob[:,index1[i],index2[i]])
        #print(sumelas[int(cov[index1[i],index2[i]]),:])
        #print(res_m[int(cov[index1[i],index2[i]]),:])
        #print(allow[int(cov[index1[i],index2[i]]),:])
        """
        for t in range(0, len(cov_list)):
            tempmax[t] = ( prob[t][index1[i]][index2[i]] + sumelas[int(cov[index1[i]][index2[i]]),t] + res_m[int(cov[index1[i]][index2[i]]),t] + nei[t,index1[i],index2[i]] ) * allow[int(cov[index1[i]][index2[i]]),t]
        """

        # 找到最大转换阻力值的索引        
        max_index = np.argmax(tempmax[i,:])

        # 依据最大的索引更新下一年的土地系统

        cov_new[index1[i],index2[i]] = cov_list[max_index]

    return cov_new

def iter_after_loop(cov, index1, index2, cov_list, lusmatrix, res, intertia, demand, prob, nei, allow, weight):
    """
        计算一次迭代发生的变化, 每变化一个像元就要计算一次
        变量解释：
        cov: 本次迭代中输入的土地数据
        index1: 土地数据中非 -9998 和 非 -9999 的位置，行坐标
        index2: 土地数据中非 -9998 和 非 -9999 的位置，列坐标
        cov_list: 土地类型的编号列表
        lusmatrix: 供给能力
        res: 转换阻力值
        demand: 下一次迭代的需求
        prob: 回归的结果
        nei: 邻域的结果
        allow: 是否允许转换
        loop: 多少次迭代之后开启逐步迭代
        region:限制区域
        如果在逐步迭代的次数之内的话, 整个区域迭代一次返回一次结果
    """
    #size = np.shape(cov)
    #cov_new = cov # 给cov_new 赋予一个初值

    # 定义一个矩阵来记录转换潜力

    # 定义一个列表，列表里面是元组，元组分别记录了变化像元的 行、列、变化的类型、以及转换潜力
    change = []

    
    # 统计一下本次迭代中变化的像元所在的位置，以及变化的类型，还有变化的潜力

    count_type = len(cov_list)

    # 定义一个矩阵存储竞争优势
    sumelas = np.zeros(shape =(count_type,count_type))

    for old_type in range(0, count_type):
        for new_type in range(0, count_type):
            for d in range(0, len(demand)):
                sumelas[old_type,new_type] = sumelas[old_type,new_type] + weight[d] * intertia[d] * ((lusmatrix[new_type][d] - lusmatrix[old_type,d]) / np.sum(lusmatrix[:,d]))

    # 顺便定义一个矩阵来存储转换阻力值
    res_m = np.zeros(shape =(count_type,count_type))

    for tt in range(0, count_type):
        res_m[tt][tt] = res[tt]

    count_cell = len(index1)
    #print(count_cell)
    #print(np.shape(prob))
    #print(np.shape(sumelas))
    #print(np.shape(res_m))
    #print(np.shape(nei))
    tempmax = np.zeros(shape = (count_cell, count_type))

    for i in range(0, count_cell):
        # 进行迭代
        #print(prob[:,index1[i],index2[i]])
        #print(sumelas[int(cov[index1[i]][index2[i]]),:])
        #print(res_m[int(cov[index1[i]][index2[i]]),:])
        #print(nei[:,index1[i],index2[i]])
        #print(allow[int(cov[index1[i]][index2[i]]),:])
        #print(index1[i],index2[i])
        tempmax[i,:] =  prob[:,index1[i],index2[i]] + sumelas[int(cov[index1[i],index2[i]]),:] + res_m[int(cov[index1[i],index2[i]]),:] + nei[:,index1[i],index2[i]] 
        
        for qq in range(count_type):
            if allow[int(cov[index1[i],index2[i]]),qq] == 0:
                tempmax[i,qq] = float('-inf')
        """
        for t in range(0, len(cov_list)):
            tempmax[t] = ( prob[t][index1[i]][index2[i]] + sumelas[int(cov[index1[i]][index2[i]]),t] + res_m[int(cov[index1[i]][index2[i]]),t] + nei[t,index1[i],index2[i]] ) * allow[int(cov[index1[i]][index2[i]]),t]
        """

        # 找到最大转换阻力值的索引        
        max_index = np.argmax(tempmax[i,:])

        if cov_list[max_index] != cov[index1[i],index2[i]]:
            change.append([index1[i], index2[i], cov_list[max_index], np.max(tempmax[i,:])])

    # 依据change这个变量， 来一个一个的变化像元

    # 对change这个变量，依据转换潜力进行排序
    change_sort = sorted(change, key=lambda x:x[3], reverse=True)
    print(change_sort)
    # 其中，reverse=True 表示按照降序进行排列，x[3] 表示按照第4个元素进行排序

    return change_sort

def comp_demand(data, cov, capacity, demand, intertia, speed, step):
    """ 
    计算每种土地系统服务之间的供需差异以及一些迭代变量
    data 指的是输入的土地数据
    cov 输入的是
    capacity 指的是供给能力
    demand 输入的是当前的需求
    demlas 输入的是供需差异
    speed 输入的是迭代变量
    step 输入的是步长
    
    """
    #print('?')
    # 依据土地数据计算当前的供给
    supply = np.zeros(shape=len(demand)) # 定义一个初始的supply矩阵
    for d in range(0, len(demand)):
        for i in range(0, len(cov)):
            supply[d] = supply[d] + np.sum(data == cov[i]) * capacity[i,d]

    # 计算当前的供需差异
    dem_elas = (demand - supply) / demand
    #print(demand,supply,dem_elas)
    # 计算当前的迭代变量
    # print('Speed is' ,str(speed))
    #print(intertia,dem_elas)

    # 将Speed 转换为每个与demand相同的列数
    #Speed = np.zeros(shape=len(demand))
    
    #print(intertia,dem_elas,Speed)
    intertia = intertia + dem_elas / speed
    # 因为增加的这段内容？
    #for d in range(0, len(demand)):
        #if abs(dem_elas[d]) > 2:
            #dem_elas[d]  = 0

    speed = speed + step
    #print(speed, Step)
    return [intertia, speed, supply]

def comp_demand2(data, cov, capacity, demand):
    # 依据土地数据计算当前的供给
    supply = np.zeros(shape=len(demand)) # 定义一个初始的supply矩阵
    #print(supply)
    #print(demand)
    for d in range(0, len(demand)):
        for i in range(0, len(cov)):
            supply[d] = supply[d] + np.sum(data == cov[i]) * capacity[i,d]

    # 计算当前的供需差异
    dem_elas = (demand - supply) / demand
    
    #print(dem_elas)
    return [dem_elas, supply]

def cal_condition(demand, supply, condition):
    """
        这个用来计算是否满足了迭代停止的条件
        dem 是当前的供需误差
        condition 是停止迭代的条件，第一个数字是平均误差，第二个数字是最大误差

        对于返回的结果中，flag等于0 说明没有满足设置的条件
        flag 等于1 说明满足了设置的条件
    """
    dem = (demand - supply) / demand
    
    # 计算平均误差
    ave_error = np.mean(abs(dem)) * 100 # 转换为百分数
    max_error = np.max(abs(dem)) * 100
    #print(ave_error,max_error,condition[0],condition[1])  # condition 的读取是有问题的
    if abs(ave_error) <= condition[1] and abs(max_error) <= condition[2]:
        flag = 1
    else:
        flag = 0

    return [flag,ave_error, max_error]
    
def cal_condition_1(supply, demand, condition):
    
    # 计算绝对误差

    enheng = 0
    for dd in range(len(condition) - 1):
        if abs(supply[dd] - demand[dd]) <= condition[ 1 + dd]:
            enheng = enheng + 1
    
    return enheng 

def WriteResult(data, xllcorner,yllcorner,cellsize,year):
    """
        这个函数的功能是用来输出模拟得到的结果的
    """
    size = np.shape(data)

    # 设置头文件
    head = ['','','','','','']
    head[0] = 'ncols'+ '\t' + str(size[1])
    head[1] = 'nrows' + '\t' + str(size[0])
    head[2] = 'xllcorner' + '\t' + str(xllcorner[0])
    head[3] = 'yllcorner' + '\t' + str(yllcorner[0] - cellsize[0] * size[0])
    head[4] = 'cellsize' + '\t' + str(cellsize[0])
    head[5] = 'NODATA_value' + '\t' + str(-9999)
    
    size = np.shape(data)
    fig = open(os.path.join(os.path.dirname(__file__),'Data','cov_all.'+str(year)+'.asc'), 'w')
    # 输入头文件
    for h in range(len(head)):
        fig.write(head[h])
        fig.write("\n")

    for i in range(0,size[0]):
        for j in range(0,size[1]):
            fig.write(("%d" % data[i][j]))
            fig.write('\t')
        fig.write("\n")
    
    print("Finished!!")

fig = open(os.path.join(os.path.dirname(__file__),'Data/log.fil'), 'w')
fig.write('Start of simulation at: ')
fig.write(str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())))
fig.write('\n')

[res, weight, condition, Seed, Step, myloop,flag,max_loop] = ReadMainParameters('Data/main.1',fig)
#print(res, weight, condition, Seed, Step)
[cov, cov_list, region, df, xllcorner,yllcorner,cellsize] = checkASCData('Data',fig)

[demand, allyear]= ReadDemand('Data/demand.in1',fig)
capacity = ReadCapacity('Data/lusmatrix.txt')

[nei_weight, nei_size, nei_coefficient, nei_constant] = ReadNeighbor('Data/neigh.txt',len(cov_list),fig)
#print(len(cov_list))

allow = ReadAllow('Data/allow.txt')

# CalNeighbor(cov, nei_weight, nei_size, nei_coefficient, nei_constant)

"""
    定义一个全局变量，用来进行遍历和循环，从而增加迭代速度
"""
global index_r,index_c,count_cell
index_r = []
index_c = []
size = np.shape(cov)
#print(size)
for i in range(0, size[0]):
    for j in range(0, size[1]):
        if cov[i,j] != -9999 and region[i,j] != -9998:
            index_r.append(i)
            index_c.append(j)

print('count:', len(index_r))

# 读取prob文件
prob = ReadProb(len(cov_list),size[0], size[1], fig)
# 开始正式迭代
# 新建一个变量，储存每一年迭代的结果

new_cov = np.zeros(shape=(allyear,size[0],size[1]))
new_cov[0,:,:] = cov * 1

for year in range(1, allyear):
    fig.write('Now simulatin year: '+str(year) + '\n')
    fig.write('__________________________' + '\n')
    new_cov[year,:,:] = new_cov[year-1,:,:] * 1 # 给new_cov先赋予一个初值，注意深拷贝和浅拷贝的问题
    speed = Seed * 1

    # 计算邻域效应，邻域效应只在每一年的时候更新计算
    # 此时的 new_cov[year,:,:] 还等于 new_cov[year-1,:,:]
    neigh_result = CalNeighbor(new_cov[year - 1 ,:,:], nei_weight, nei_size, nei_coefficient, nei_constant)
    print('The max neigh is:',np.max(neigh_result))

    # 定义一个初始的intertia
    size_demand = np.shape(demand)

    if len(size_demand) == 1:
        intertia = 0
    else:
        intertia = np.zeros(shape = len(demand[year,:]))

    #print(max_loop)
    for it in range(0, int(max_loop)):
        # 进行一次迭代
        print(it)
        #print(dem_elas,supply)
        # 判断当前的迭代次数
        if it <= int(myloop):
            
            # 进行迭代
            if len(size_demand) == 1:
                new_cov[year,:,:] = iter(new_cov[year - 1,:,:], index_r, index_c, cov_list, capacity, res, intertia, demand[year], prob, neigh_result, allow, weight)
        
                # 计算当前的供需差异
                [intertia, speed,  supply] = comp_demand(new_cov[year,:,:], cov_list, capacity, demand[year],intertia,speed, Step)
            else:
                new_cov[year,:,:] = iter(new_cov[year - 1,:,:], index_r, index_c, cov_list, capacity, res, intertia, demand[year,:], prob, neigh_result, allow, weight)
            
                # 计算当前的供需差异
                [intertia, speed,  supply] = comp_demand(new_cov[year,:,:], cov_list, capacity, demand[year,:],intertia,speed, Step)

            if condition[0] == 0:

                # 判断当前是否终止循环

                if len(size_demand) == 1:
                    [flag, ave_error, max_error] = cal_condition(demand[year], supply, condition)
                else:
                    [flag, ave_error, max_error] = cal_condition(demand[year,:], supply, condition)

                # 进行一些文本的输出
                fig.write(str(it) + '\t')
                for de in range(len(supply)):
                    fig.write(str('%.2f' % supply[de]) + '\t')
                fig.write('ave_error: ' + str('%.2f' % ave_error) +'\t' +  'max_error: ' +  str('%.2f' % max_error) + '\n')
                fig.flush() 

                if flag == 1:
                    # 将结果输出后，停止代码的运行
                    WriteResult(new_cov[year,:,:], xllcorner,yllcorner,cellsize,year)
                    fig.write('__________ Finished at ' +  str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())) + ' ________________')
                    #break
                    sys.exit('OK!')

            if condition[0] == 1:
                
                # 判断当前是否终止循环
                if len(size_demand) == 1:
                    flag = cal_condition_1(supply, demand[year], condition)
                else:
                    flag = cal_condition_1(supply, demand[year,:], condition)
                # 进行一些文本的输出
                fig.write(str(it) + '\t')
                for de in range(len(supply)):
                    fig.write(str('%.2f' % supply[de]) + '\t')
                fig.write('ave_error: ' + str('%.2f' % ave_error) +'\t' +  'max_error: ' +  str('%.2f' % max_error) + '\n')
                fig.flush()
                #print("flag: "+ str(flag) +" iter: "+ str(it) + ' ' + 'ave_error:' + str(ave_error) + ' ' + 'max_error:' + str(max_error) + '\t'+str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())))
                if len(size_demand) == 1:

                    if flag == len(demand[year]):
                        # 将结果输出后，停止代码的运行
                        WriteResult(new_cov[year,:,:], xllcorner,yllcorner,cellsize,year)
                        fig.write('__________ Finished at ' +  str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())) + ' ________________')
                        sys.exit('OK!')

                else:

                    if flag == len(demand[year,:]):
                        # 将结果输出后，停止代码的运行
                        WriteResult(new_cov[year,:,:], xllcorner,yllcorner,cellsize,year)
                        fig.write('__________ Finished at ' +  str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())) + ' ________________')
                        sys.exit('OK!')

        else:

            if len(size_demand) == 1:

                change = iter_after_loop(new_cov[year,:,:], index_r, index_c, cov_list, capacity, res, intertia, demand[year], prob, neigh_result, allow, weight)
            else:

                change = iter_after_loop(new_cov[year,:,:], index_r, index_c, cov_list, capacity, res, intertia, demand[year,:], prob, neigh_result, allow, weight)
            
            for ch in range(0, len(change)):

                new_cov[year,int(change[ch][0]),int(change[ch][1])] = int(change[ch][2]) * 1
                
                #print(condition[0])
                if condition[0] == 0:
                    
                    #print('heihei')
                    # 变化一个像元就要计算一次限差
                    if len(size_demand) == 1:
                        [dem, supply] = comp_demand2(new_cov[year,:,:], cov_list, capacity, demand[year])
                    else:
                        [dem, supply] = comp_demand2(new_cov[year,:,:], cov_list, capacity, demand[year,:])

                     # 进行一些文本输出
                    fig.write(str(it) + '\t')
                    #print(it)
                    for de in range(len(supply)):
                        fig.write(str('%.2f' % supply[de]) + '\t')
                    fig.write('ave_error: ' + str('%.2f' % ave_error) +'\t' +  'max_error: ' +  str('%.2f' % max_error) + '\n')
                    fig.flush()

                    if len(size_demand) == 1:

                        [flag, ave_error, max_error] = cal_condition(demand[year], supply, condition)
                    else:

                        [flag, ave_error, max_error] = cal_condition(demand[year,:], supply, condition)

                    if flag == 1:
                        WriteResult(new_cov[year,:,:], xllcorner,yllcorner,cellsize,year)
                        fig.write('__________ Finished at ' +  str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())) + ' ________________' + '\n')
                        sys.exit('OK!')

                if condition[0] == 1:

                    if len(size_demand) == 1:
                        flag = cal_condition_1(supply, demand[year], condition)
                    else:
                        flag = cal_condition_1(supply, demand[year,:], condition)

                    # 进行一些文本输出
                    fig.write(str(it) + '\t')
                    for de in range(len(supply)):
                        fig.write(str('%.2f' % supply[de]) + '\t')
                    fig.write('ave_error: ' + str('%.2f' % ave_error) +'\t' +  'max_error: ' +  str('%.2f' % max_error) + '\n')
                    fig.flush()

                    if len(size_demand) == 1:

                        if flag == len(demand[year]):
                            WriteResult(new_cov[year,:,:], xllcorner,yllcorner,cellsize,year)
                            fig.write('__________ Finished at ' +  str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())) + ' ________________' + '\n')
                            sys.exit('OK!')  
                    else:

                        if flag == len(demand[year,:]):
                            WriteResult(new_cov[year,:,:], xllcorner,yllcorner,cellsize,year)
                            fig.write('__________ Finished at ' +  str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())) + ' ________________' + '\n')
                            sys.exit('OK!')    
            if len(size_demand) == 1:

                [intertia, speed,  supply] = comp_demand(new_cov[year,:,:], cov_list, capacity, demand[year],intertia,speed, Step)
            else:

                [intertia, speed,  supply] = comp_demand(new_cov[year,:,:], cov_list, capacity, demand[year,:],intertia,speed, Step)



