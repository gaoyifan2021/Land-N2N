import numpy as np
from osgeo import gdal
import os

os.environ["SM_FRAMEWORK"] = "tf.keras"
import time
import re
#os.environ["CUDA_VISIBLE_DEVICES"] = "1"
#import tensorflow_decision_forests as tf_df
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score
from sklearn.ensemble import RandomForestRegressor
from sklearn.neural_network import MLPRegressor
from tensorflow import keras
from keras.models import Sequential
from keras.layers import Dense
from sklearn.preprocessing import StandardScaler
import tensorflow as tf
from keras.layers import Activation, Dense, Dropout
import keras.backend as K
import tensorflow_decision_forests as tf_df



sample1 = 'Suitability/sample1.asc'
sample2 = 'Suitability/sample2.asc'


"""
    在这里选择回归的方式：
    0：随机森林回归
    1：ANN_binary回归
    2：随机森林（GPU）
"""

def ReadMain(filepath,fig):
    f = open(filepath)               # 返回一个文件对象 
    lines = f.readlines()
    GPU_device = re.split('\t| |\n',lines[0])
    reg_method = re.split('\t| |\n',lines[1])
    cell_condition = re.split('\t| |\n',lines[2])
    f.close()

    while '' in GPU_device:
        GPU_device.remove('')
    while '' in reg_method:
        reg_method.remove('')
    while '' in cell_condition:
        cell_condition.remove('')

    fig.write('The GPU is : ' + str(GPU_device) + '\n')

    if reg_method[0] == 0:
        fig.write('You select the Random Forest Regression from sklearn.' + '\n')
    
    if reg_method[0] == 1:
        fig.write('You select the ANN Regression from Tensorflow.' + '\n')

    if reg_method[0] == 2:
        fig.write('You select the Random Forest Regression from Tensorflow.' + '\n')

    if reg_method[0] == 3:
        fig.write('You select the Random Forest Regression from Tensorflow(Sample).' + '\n')

    fig.write('If the number of samples is less than ' + str(cell_condition[0]) + ', the regression will not be execute.' + '\n')

    return [int(GPU_device[0]), int(reg_method[0]), int(cell_condition[0])]


def CountDF(filepath,fig):
      
    fileList = []    
    for root, subDirs, files in os.walk(filepath):
        for fileName in files:
            if fileName.endswith('.asc'):
                if fileName[0] == 's' and fileName[1] == 'c' and fileName[2] == '1' and fileName[3] == 'g' and fileName[4] == 'r':
                    fileList.append(os.path.join(root,fileName))

    fig.write('The number of driving factors:' + str(len(fileList)) + '\n')

    return len(fileList)

def ReadGeoASC(filepath):
    """ Read raster data in ASC format """

    dataset = gdal.Open(os.path.join(os.path.dirname(__file__),filepath))
    # print(dataset)
    im_width = dataset.RasterXSize  # Get the row of the data

    im_height = dataset.RasterYSize  # Get the col of the data
    #print(im_width, im_height)
    band = dataset.GetRasterBand(1)  # Get the band
    im_datas = band.ReadAsArray(0, 0, im_width, im_height)  # Get the data
    
    im_geotrans = dataset.GetGeoTransform()
    """
        xllcorner = im_geotrans[0]
        yllcorner = im_geotrans[3]
        cellsize = im_geotrans[1]
    """

    #print(im_geotrans)
    #print(im_geotrans)
    return [im_datas,im_geotrans]

def Sample_change(path1, path2, count_df):
    [cov1, geo1] = ReadGeoASC(path1)
    [cov2, geo2] = ReadGeoASC(path2)
    
    type_count = np.max([np.max(cov1),np.max(cov2)])+1

    # 首先确定有多少土地类型
    #cov_list = []
    #print(np.max(cov1),np.max(cov2))
    #for i in range(0, type_count):
        # 被这个左开右闭气死了啊！
        #if np.sum(cov1 == i) != 0 or np.sum(cov1 == i) != 0:
            #cov_list.append(i)
    # 计算这个区域的非nodata的像元个数
    cell_count = np.sum(cov1 != -9999)
    
    # 通过循环找到制作变化的像元
    size = np.shape(cov1)
    
    #type_count = len(cov_list)

    k = 0
    cov = np.zeros(shape = (size[0] * size[1], type_count)) # 有nodata的数据
    temp = np.zeros(shape=(1, type_count))
    temp[temp == 0] = -9999
               
    for i in range(0, size[0]):
        for j in range(0, size[1]):
            #print(im_datas[i][j])
            if cov1[i,j] == -9999:
                cov[k,:] = temp
                k = k + 1
            else:
                if cov1[i,j] != cov2[i,j]:
                    cov[k][int(cov2[i,j])] = 1
                    k = k + 1
                else:
                    cov[k][int(cov2[i,j])] = 0
                    k = k + 1
    #print(cov.shape)
    # 去掉nodata数据，用来回归
    cov_without_nodata = np.empty(shape=(cell_count,type_count))
    #print(cell_count)
    p = 0
    for i in range(0, size[0] * size[1]):
        if cov[i][0] != -9999:
            cov_without_nodata[p,0:type_count] = cov[i,0:type_count] * 1
            p = p + 1
            #print(p,i)

    # 读取驱动因子
    df = np.empty(shape=(size[0] * size[1], count_df))

    for df_index in range(0, count_df):
        k = 0
        [df_data, geo]= ReadGeoASC(os.path.join(os.path.dirname(__file__),"Suitability", 'sc1gr'+ str(df_index) + '.fil.asc'))
        for i in range(0, size[0]):
            for j in range(0, size[1]):
                df[k, df_index] = df_data[i,j]
                k = k + 1
    df_without_nodata = np.empty(shape=(cell_count, count_df))  

    p = 0
    for i in range(0, size[0] * size[1]):
        if df[i,0] != -9999:
            df_without_nodata[p,0:count_df] = df[i,0:count_df]
            p = p + 1     

    # 还需要去除[0,0,0,0,0] 这样的标签
    # 记录一个数字，确定有类别标签的矩阵有多少
    location = []
    

    for i in range(cell_count):
        if np.sum(cov_without_nodata[i,:]) != 0:
            location.append(i)

    count_label = len(location)

    # cov_label 和 df_label
    cov_label = np.empty(shape=(count_label,type_count))
    df_label = np.empty(shape=(count_label,count_df))

    for i in range(count_label):
        cov_label[i,:] = cov_without_nodata[location[i],:]
        df_label[i,:] = df_without_nodata[location[i],:]

    return [cov , cov_without_nodata , df , df_without_nodata , type_count, size, cov_label, df_label]

def RandomForest(path_head, Sample_X, Sample_Y, Pred_X,  type_count, size, fig_log, count_cell):
    """
        path_head 是用来参照头文件的文件
        Sample_X 输入的是用来采样的驱动因子
        Sample_Y 输入的是用来采样的土地数据
        Pred_X 输入的是用来预测的驱动因子
        type_count 是土地类型的数量
    """
    size_df = np.shape(Sample_X)
    #print(size_df)
    # 读取头文件
    f = open(path_head,'r')
    head = []
    for i in range(6):
        head.append(f.readline().strip())
    
    # 对每一种土地系统类型进行回归
    for i in range(0, type_count):
        # 确定因变量
        y = Sample_Y[:,i]
        #print(y.shape)
        # 初始化计算结果
        result = []
        # 将数据分为测试集和训练集
        X_train, X_test, y_train, y_test = train_test_split(Sample_X,
                                                            y,
                                                            test_size = 0.75,
                                                            random_state = 0,
                                                            )
        #print(Sample_X.shape, y.shape)
        #print(Sample_X[0,:],y[0])
        #print( y_train)
        #print('!!!')
        # 各参数的解释
        # X_train,X_test, y_train, y_test =sklearn.model_selection.train_test_split(train_data,train_target,test_size=0.4, random_state=0,stratify=y_train)
        # train_target：所要划分的样本结果
        # test_size：样本占比，如果是整数的话就是样本的数量
        # random_state：是随机数的种子。
        # 随机数种子：其实就是该组随机数的编号，在需要重复试验的时候，保证得到一组一样的随机数。比如你每次都填1，其他参数一样的情况下你得到的随机数组是一样的。但填0或不填，每次都会不一样。

        # 特征缩放，通常没必要
        # 因为数据单位，自变量数值范围差距巨大，不缩放也没问题
        # sc = StandardScaler()
        # X_train = sc.fit_transform(X_train)
        # X_test = sc.transform(X_test)

        if sum(y_train) <= count_cell:
            # 如果没有抽到样的话，则说明样本数量太少，不用进行回归
            # 直接输出结果（概率值都为0）
            for j in range(0, size[0] * size[1]):
                # 如果原始数据为-9999，那么概率值就为-9999
                if Pred_X[j][0] == -9999:
                    result.append(-9999)
                else:
                    result.append(0)
            # 将计算结果输出成文件
            fig_log.write('The land system ' + str(i) + ' has not enough samples to regression.' + '\n')
            fig_log.write('____________________________________________________________________' + '\n')
            #fig_log.write('The AUC of the land system ' + str(i) + ' :' +  str(train_auc) + '\n')
            fig_log.flush()
            fig = open(os.path.join(os.path.dirname(__file__),'Data/prob1_'+str(i)+'.1.asc'), 'w')
            for m in range(0, len(head)):
                fig.write(head[m])
                fig.write('\n')
            for n in range(0, len(result)):
                fig.write(str(result[n]))
                fig.write('\n')
            # 关闭文件流
            fig.close()
        else:
            #print(size_df[1])
            model = RandomForestRegressor(n_estimators = 200, random_state = 0, oob_score = True, max_features = size_df[1],n_jobs=-1)
            #regressor = RandomForestRegressor(n_estimators=200, random_state=0, )
            model.fit(X_train,y_train)
            # 计算各个驱动因子的重要性程度
            features_imp = model.feature_importances_
            #indices = np.argsort(features_imp)[::-1]
            

            #for imp in range(0,len(features_imp)):
                #print(model.feature_importances_[imp])
            #print('###')
            # 验证精度如何
            y_test_pred = model.predict(X_test)  # 预测
            # 评估逻辑回归的性能-这里用ROC曲线/AUC值
            # 参考学习的链接
            # https: // www.cxyzjd.com / article / qq_35098624 / 106456237

            #train_auc =tf_df.keras.AdvancedArguments(y_train, y_pred)
            # 测试集的AUC
            train_auc = roc_auc_score(y_test, y_test_pred)
            """
            sklearn.metrics.roc_auc_score(y_true, y_score, *, average='macro', sample_weight=None, max_fpr=None, multi_class='raise', labels=None)
            """
            
            # 蒋各个驱动因子的重要性程度输出
            
            fig_log.write('The AUC of the land system ' + str(i) + ' :' +  str(train_auc) + '\n')
            for imp in range(size_df[1]):
                fig_log.write('The importance of the driving factor '+ str(imp) + ' is : ' + str((features_imp[imp])) + '\n')
            fig_log.write('____________________________________________________________________' + '\n')
            fig_log.flush()
            #print("土地系统类型",str(i),"的AUC值为：",str(train_auc))
            # 计算全部数据的概率
            # 每9W次计算一次概率
            result_pred = model.predict(Sample_X)
            #print(result_pred)
            # 插入-9999值
            t = 0
            for j in range(0, size[0] * size[1]):
                # 如果原始数据为-9999，那么概率值就为-9999
                if Pred_X[j][0] == -9999:
                    result.append(-9999)
                else:
                    # 如果不是的话，就填入概率值
                    result.append(result_pred[t])
                    t = t + 1
            #print(t)
            # 将计算结果输出成文件
            fig = open(os.path.join(os.path.dirname(__file__),'Data/prob1_'+str(i)+'.1.asc'), 'w')
            for m in range(0, len(head)):
                fig.write(head[m])
                fig.write('\n')
            for n in range(0, len(result)):
                fig.write(("%.8f" % result[n]))
                fig.write('\n')
                # 关闭文件流
            fig.close()

def RandomForest_for_test(path_head, Sample_X, Sample_Y, Pred_X,  type_count, size, fig_log, count_cell):
    """
        path_head 是用来参照头文件的文件
        Sample_X 输入的是用来采样的驱动因子
        Sample_Y 输入的是用来采样的土地数据
        Pred_X 输入的是用来预测的驱动因子
        type_count 是土地类型的数量
    """
    size_df = np.shape(Sample_X)
    #size = np.shape(Pred_X)
    #print(size_df)
    # 读取头文件
    f = open(path_head,'r')
    head = []
    for i in range(6):
        head.append(f.readline().strip())

    samples = 0
    samples_location = []
    for j in range(0, len(Sample_Y[:,i])):
        if j % 4 == 0:
            samples = samples + 1
            samples_location.append(j)
    
    # 将这个坐标输出
    fig_location_log = open(os.path.join(os.path.dirname(__file__),'Data/log_samples.fil'), 'w')

    for j in range(0, samples):
        fig_location_log.write(str(samples_location[j]) + '\n')
    # 划分样本
    X_train = np.empty(shape = (samples, size_df[1]))
    X_test = np.empty(shape = (size_df[0] - samples, size_df[1]))
    Y_train = np.empty(shape = (samples, type_count))
    Y_test = np.empty(shape = (size_df[0] - samples, type_count))

    n_train = 0
    n_test = 0

    for j in range(0, len(Sample_Y[:,i])):
        if j % 4 == 0:
            X_train[n_train,:] = Sample_X[j,:]
            Y_train[n_train,:] = Sample_Y[j,:]
            n_train = n_train + 1
        else:
            X_test[n_test,:] = Sample_X[j,:]
            Y_test[n_test,:] = Sample_Y[j,:]
            n_test= n_test + 1

    # 对每一种土地系统类型进行回归
    for i in range(0, type_count):
        # 确定因变量
        #y = Sample_Y[:,i]
        #print(y.shape)
        # 初始化计算结果
        result = []
        # 将数据分为测试集和训练集
        #X_train, X_test, y_train, y_test = train_test_split(Sample_X,
        #                                                    y,
        #                                                    test_size = 0.75,
        #                                                    random_state = 0,
        #                                                    )

        y_train = Y_train[:,i]
        y_test = Y_test[:,i]

        #print(Sample_X.shape, y.shape)
        #print(Sample_X[0,:],y[0])
        #print( y_train)
        #print('!!!')
        # 各参数的解释
        # X_train,X_test, y_train, y_test =sklearn.model_selection.train_test_split(train_data,train_target,test_size=0.4, random_state=0,stratify=y_train)
        # train_target：所要划分的样本结果
        # test_size：样本占比，如果是整数的话就是样本的数量
        # random_state：是随机数的种子。
        # 随机数种子：其实就是该组随机数的编号，在需要重复试验的时候，保证得到一组一样的随机数。比如你每次都填1，其他参数一样的情况下你得到的随机数组是一样的。但填0或不填，每次都会不一样。

        # 特征缩放，通常没必要
        # 因为数据单位，自变量数值范围差距巨大，不缩放也没问题
        # sc = StandardScaler()
        # X_train = sc.fit_transform(X_train)
        # X_test = sc.transform(X_test)

        if np.sum(y_train) <= count_cell:
            # 如果没有抽到样的话，则说明样本数量太少，不用进行回归
            # 直接输出结果（概率值都为0）
            for j in range(0, size[0] * size[1]):
                # 如果原始数据为-9999，那么概率值就为-9999
                if Pred_X[j][0] == -9999:
                    result.append(-9999)
                else:
                    result.append(0)
            # 将计算结果输出成文件
            fig_log.write('The land system ' + str(i) + ' has not enough samples to regression.' + '\n')
            fig_log.write('____________________________________________________________________' + '\n')
            #fig_log.write('The AUC of the land system ' + str(i) + ' :' +  str(train_auc) + '\n')
            fig_log.flush()
            fig = open(os.path.join(os.path.dirname(__file__),'Data/prob1_'+str(i)+'.1.asc'), 'w')
            for m in range(0, len(head)):
                fig.write(head[m])
                fig.write('\n')
            for n in range(0, len(result)):
                fig.write(str(result[n]))
                fig.write('\n')
            # 关闭文件流
            fig.close()
        else:
            #print(size_df[1])
            model = RandomForestRegressor(n_estimators = 200, random_state = 0, oob_score = True, max_features = size_df[1],n_jobs=-1)
            #regressor = RandomForestRegressor(n_estimators=200, random_state=0, )
            model.fit(X_train,y_train)
            # 计算各个驱动因子的重要性程度
            features_imp = model.feature_importances_
            #indices = np.argsort(features_imp)[::-1]
            

            #for imp in range(0,len(features_imp)):
                #print(model.feature_importances_[imp])
            #print('###')
            # 验证精度如何
            y_test_pred = model.predict(X_test)  # 预测
            # 评估逻辑回归的性能-这里用ROC曲线/AUC值
            # 参考学习的链接
            # https: // www.cxyzjd.com / article / qq_35098624 / 106456237

            #train_auc =tf_df.keras.AdvancedArguments(y_train, y_pred)
            # 测试集的AUC
            train_auc = roc_auc_score(y_test, y_test_pred)
            """
            sklearn.metrics.roc_auc_score(y_true, y_score, *, average='macro', sample_weight=None, max_fpr=None, multi_class='raise', labels=None)
            """
            oob_error = model.oob_score_

            
            
            # 蒋各个驱动因子的重要性程度输出

            fig_log.write('The OOB error of the land system ' + str(i) + ' :' +  str(oob_error) + '\n')
            fig_log.write('The AUC of the land system ' + str(i) + ' :' +  str(train_auc) + '\n')
            for imp in range(size_df[1]):
                fig_log.write('The importance of the driving factor '+ str(imp) + ' is : ' + str((features_imp[imp])) + '\n')
            fig_log.write('____________________________________________________________________' + '\n')
            fig_log.flush()
            #print("土地系统类型",str(i),"的AUC值为：",str(train_auc))
            # 计算全部数据的概率
            # 每9W次计算一次概率
            result_pred = model.predict(Sample_X)
            #print(result_pred)
            # 插入-9999值
            t = 0
            for j in range(0, size[0] * size[1]):
                # 如果原始数据为-9999，那么概率值就为-9999
                if Pred_X[j][0] == -9999:
                    result.append(-9999)
                else:
                    # 如果不是的话，就填入概率值
                    result.append(result_pred[t])
                    t = t + 1
            #print(t)
            # 将计算结果输出成文件
            fig = open(os.path.join(os.path.dirname(__file__),'Data/prob1_'+str(i)+'.1.asc'), 'w')
            for m in range(0, len(head)):
                fig.write(head[m])
                fig.write('\n')
            for n in range(0, len(result)):
                fig.write(("%.8f" % result[n]))
                fig.write('\n')
                # 关闭文件流
            fig.close()


''' focal loss 二分类时候用这个'''
def binary_focal_loss(gamma=2, alpha=0.25):
    alpha = tf.constant(alpha, dtype=tf.float32)
    gamma = tf.constant(gamma, dtype=tf.float32)

    def binary_focal_loss_fixed(y_true, y_pred):
        """
        y_true shape need be (None,1)
        y_pred need be compute after sigmoid
        """
        y_true = tf.cast(y_true, tf.float32)
        alpha_t = y_true * alpha + (K.ones_like(y_true) - y_true) * (1 - alpha)

        p_t = y_true * y_pred + (K.ones_like(y_true) - y_true) * (K.ones_like(y_true) - y_pred) + K.epsilon()
        focal_loss = - alpha_t * K.pow((K.ones_like(y_true) - p_t), gamma) * K.log(p_t)
        return K.mean(focal_loss)

    return binary_focal_loss_fixed

def ANN(path_head, Sample_X, Sample_Y, Pred_X,  type_count, size, fig_log, count_cell):
    """
        path_head 是用来参照头文件的文件
        Sample_X 输入的是用来采样的驱动因子
        Sample_Y 输入的是用来采样的土地数据
        Pred_X 输入的是用来预测的驱动因子
        type_count 是土地类型的数量
    """
    # 读取学习率等内容
    con = np.loadtxt('Suitability/config.txt')
    print(con)
    size_df = np.shape(Sample_X)

    f = open(path_head,'r')
    head = []
    for i in range(6):
        head.append(f.readline().strip())
    
    # 对每一种土地系统类型进行回归
    for i in range(0, type_count):
        # 确定因变量
        y = Sample_Y[:,i]
        # 调整样本为向量
        yy = np.empty(shape=(len(y),2))

        for qq in range(len(y)):
            if y[qq] == 0:
                yy[qq,:] = [1,0]
            else:
                yy[qq,:] = [0,1]

        #print(y.shape)
        # 初始化计算结果
        result = []
        # 将数据分为测试集和训练集
        
        #PredictorScaler = StandardScaler()
        #TargetVarScaler = StandardScaler()

        #PredictorScalerFit=PredictorScaler.fit(Sample_X)
        #TargetVarScalerFit=TargetVarScaler.fit(y.reshape(1, -1))

        #Sample_X = PredictorScalerFit.transform(Sample_X)
        #y = TargetVarScalerFit.transform(y.reshape(1, -1))

        X_train, X_test, y_train, y_test = train_test_split(Sample_X,
                                                            yy,
                                                            test_size = 0.75,
                                                            random_state = 0,
                                                            )

        if sum(y_train[:,1]) <= count_cell:
            # 如果没有抽到样的话，则说明样本数量太少，不用进行回归
            # 直接输出结果（概率值都为0）
            for j in range(0, size[0] * size[1]):
                # 如果原始数据为-9999，那么概率值就为-9999
                if Pred_X[j][0] == -9999:
                    result.append(-9999)
                else:
                    result.append(0)
            # 将计算结果输出成文件
            fig_log.write('The land system ' + str(i) + ' has not enough samples to regression.' + '\n')
            fig_log.write('____________________________________________________________________' + '\n')
            #fig_log.write('The AUC of the land system ' + str(i) + ' :' +  str(train_auc) + '\n')
            fig_log.flush()
            fig = open(os.path.join(os.path.dirname(__file__),'Data/prob1_'+str(i)+'.1.asc'), 'w')
            for m in range(0, len(head)):
                fig.write(head[m])
                fig.write('\n')
            for n in range(0, len(result)):
                fig.write(str(result[n]))
                fig.write('\n')
            # 关闭文件流
            fig.close()

        else:
            
            # create ANN model
            model = Sequential()

            # 学习链接
            # https://thinkingneuron.com/using-artificial-neural-networks-for-regression-in-python/
            # Defining the Input layer and FIRST hidden layer, both are same!
            model.add(Dense(units = size_df[1], input_dim = size_df[1], kernel_initializer='normal', activation='relu'))

            # Defining the Second layer of the model
            # after the first layer we don't have to specify input_dim as keras configure it automatically
            model.add(Dense(units = 64, kernel_initializer='normal', activation='relu'))

            model.add(Dense(units = 128, kernel_initializer='normal', activation='relu'))

            model.add(Dense(units = 64, kernel_initializer='normal', activation='relu'))
            model.add(Dense(units = 32, kernel_initializer='normal', activation='relu'))
            model.add(Dense(units = 16, kernel_initializer='normal', activation='relu'))

            # The output neuron is a single fully connected node 
            # Since we will be predicting a single number
            model.add(Dense(2, kernel_initializer='normal'))
            model.add(Dropout(0.2)) # 为了避免过拟合所设置的参数
            model.add(Activation('softmax'))
            from keras import optimizers
            sgd = optimizers.SGD(learning_rate = con[i,2],clipvalue = 0.5)
            # Compiling the model
            #model.compile(loss='mean_squared_error', optimizer=sgd)
            model.compile(loss=[binary_focal_loss(alpha=.25, gamma=2)], metrics=["accuracy"], optimizer=sgd)

            # Fitting the ANN to the Training set
            model.fit(X_train, y_train ,batch_size = int(con[i,0]), epochs = int(con[i,1]), verbose=1)

            y_test_pred = model.predict(X_test)  # 预测
            #y_test_pred = TargetVarScalerFit.inverse_transform(y_test_pred)
            #y_test_pred = y_test_pred[0]
            # 评估逻辑回归的性能-这里用ROC曲线/AUC值
            # 参考学习的链接
            # https: // www.cxyzjd.com / article / qq_35098624 / 106456237

            #train_auc =tf_df.keras.AdvancedArguments(y_train, y_pred)
            # 测试集的AUC
            train_auc = roc_auc_score(y_test[:,1], y_test_pred[:,1])
            """
            sklearn.metrics.roc_auc_score(y_true, y_score, *, average='macro', sample_weight=None, max_fpr=None, multi_class='raise', labels=None)
            """
            #oob_error = model.oob_score_

            
            
            # 蒋各个驱动因子的重要性程度输出

            #fig_log.write('The OOB error of the land system ' + str(i) + ' :' +  str(oob_error) + '\n')
            fig_log.write('The AUC of the land system ' + str(i) + ' :' +  str(train_auc) + '\n')
            #for imp in range(size_df[1]):
                #fig_log.write('The importance of the driving factor '+ str(imp) + ' is : ' + str((features_imp[imp])) + '\n')
            fig_log.write('____________________________________________________________________' + '\n')
            fig_log.flush()
            #print("土地系统类型",str(i),"的AUC值为：",str(train_auc))
            # 计算全部数据的概率
            # 每9W次计算一次概率
            result_pred = model.predict(Sample_X)
            #print(result_pred)
            # 插入-9999值
            t = 0
            for j in range(0, size[0] * size[1]):
                # 如果原始数据为-9999，那么概率值就为-9999
                if Pred_X[j][0] == -9999:
                    result.append(-9999)
                else:
                    # 如果不是的话，就填入概率值
                    result.append(result_pred[t,1])
                    t = t + 1
            #print(t)
            # 将计算结果输出成文件
            fig = open(os.path.join(os.path.dirname(__file__),'Data/prob1_'+str(i)+'.1.asc'), 'w')
            for m in range(0, len(head)):
                fig.write(head[m])
                fig.write('\n')
            for n in range(0, len(result)):
                fig.write(("%.8f" % result[n]))
                fig.write('\n')
                # 关闭文件流
            fig.close()

def RandomForest_GPU(path_head, Sample_X, Sample_Y, Pred_X,  type_count, size, fig_log, count_cell):
    """
        path_head 是用来参照头文件的文件
        Sample_X 输入的是用来采样的驱动因子
        Sample_Y 输入的是用来采样的土地数据
        Pred_X 输入的是用来预测的驱动因子
        type_count 是土地类型的数量
    """
    size_df = np.shape(Sample_X)
    #print(size_df)
    # 读取头文件
    f = open(path_head,'r')
    head = []
    for i in range(6):
        head.append(f.readline().strip())
    
    # 对每一种土地系统类型进行回归
    for i in range(0, type_count):
        # 确定因变量
        y = Sample_Y[:,i]
        #print(y.shape)
        # 初始化计算结果
        result = []
        # 将数据分为测试集和训练集
        X_train, X_test, y_train, y_test = train_test_split(Sample_X,
                                                            y,
                                                            test_size = 0.75,
                                                            random_state = 0,
                                                            )
        #print(Sample_X.shape, y.shape)
        #print(Sample_X[0,:],y[0])
        #print( y_train)
        #print('!!!')
        # 各参数的解释
        # X_train,X_test, y_train, y_test =sklearn.model_selection.train_test_split(train_data,train_target,test_size=0.4, random_state=0,stratify=y_train)
        # train_target：所要划分的样本结果
        # test_size：样本占比，如果是整数的话就是样本的数量
        # random_state：是随机数的种子。
        # 随机数种子：其实就是该组随机数的编号，在需要重复试验的时候，保证得到一组一样的随机数。比如你每次都填1，其他参数一样的情况下你得到的随机数组是一样的。但填0或不填，每次都会不一样。

        # 特征缩放，通常没必要
        # 因为数据单位，自变量数值范围差距巨大，不缩放也没问题
        # sc = StandardScaler()
        # X_train = sc.fit_transform(X_train)
        # X_test = sc.transform(X_test)

        if sum(y_train) <= count_cell:
            # 如果没有抽到样的话，则说明样本数量太少，不用进行回归
            # 直接输出结果（概率值都为0）
            for j in range(0, size[0] * size[1]):
                # 如果原始数据为-9999，那么概率值就为-9999
                if Pred_X[j][0] == -9999:
                    result.append(-9999)
                else:
                    result.append(0)
            # 将计算结果输出成文件
            fig_log.write('The land system ' + str(i) + ' has not enough samples to regression.' + '\n')
            fig_log.write('____________________________________________________________________' + '\n')
            #fig_log.write('The AUC of the land system ' + str(i) + ' :' +  str(train_auc) + '\n')
            fig_log.flush()
            fig = open(os.path.join(os.path.dirname(__file__),'Data/prob1_'+str(i)+'.1.asc'), 'w')
            for m in range(0, len(head)):
                fig.write(head[m])
                fig.write('\n')
            for n in range(0, len(result)):
                fig.write(str(result[n]))
                fig.write('\n')
            # 关闭文件流
            fig.close()
        else:
            #print(size_df[1])
            model = tf_df.keras.RandomForestModel(task = tf_df.keras.Task.REGRESSION, num_trees = 200)
            #regressor = RandomForestRegressor(n_estimators=200, random_state=0, )
            model.fit(X_train,y_train)
            # 计算各个驱动因子的重要性程度
            #features_imp = model.feature_importances_
            #indices = np.argsort(features_imp)[::-1]
            

            #for imp in range(0,len(features_imp)):
                #print(model.feature_importances_[imp])
            #print('###')
            # 验证精度如何
            y_test_pred = model.predict(X_test)  # 预测
            # 评估逻辑回归的性能-这里用ROC曲线/AUC值
            # 参考学习的链接
            # https: // www.cxyzjd.com / article / qq_35098624 / 106456237

            #train_auc =tf_df.keras.AdvancedArguments(y_train, y_pred)
            # 测试集的AUC
            train_auc = roc_auc_score(y_test, y_test_pred)
            """
            sklearn.metrics.roc_auc_score(y_true, y_score, *, average='macro', sample_weight=None, max_fpr=None, multi_class='raise', labels=None)
            """
            #oob_error = model.oob_score_

            
            
            # 蒋各个驱动因子的重要性程度输出

            #fig_log.write('The OOB error of the land system ' + str(i) + ' :' +  str(oob_error) + '\n')
            fig_log.write('The AUC of the land system ' + str(i) + ' :' +  str(train_auc) + '\n')
            #for imp in range(size_df[1]):
                #fig_log.write('The importance of the driving factor '+ str(imp) + ' is : ' + str((features_imp[imp])) + '\n')
            fig_log.write('____________________________________________________________________' + '\n')
            fig_log.flush()
            #print("土地系统类型",str(i),"的AUC值为：",str(train_auc))
            # 计算全部数据的概率
            # 每9W次计算一次概率
            result_pred = model.predict(Sample_X)
            #print(result_pred)
            # 插入-9999值
            t = 0
            for j in range(0, size[0] * size[1]):
                # 如果原始数据为-9999，那么概率值就为-9999
                if Pred_X[j][0] == -9999:
                    result.append(-9999)
                else:
                    # 如果不是的话，就填入概率值
                    result.append(result_pred[t])
                    t = t + 1
            #print(t)
            # 将计算结果输出成文件
            fig = open(os.path.join(os.path.dirname(__file__),'Data/prob1_'+str(i)+'.1.asc'), 'w')
            for m in range(0, len(head)):
                fig.write(head[m])
                fig.write('\n')
            for n in range(0, len(result)):
                fig.write(("%.8f" % result[n]))
                fig.write('\n')
                # 关闭文件流
            fig.close()


fig_log = open(os.path.join(os.path.dirname(__file__),'Data/log_regression.fil'), 'w')
fig_log.write('Start of simulation at: ')
fig_log.write(str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())))
fig_log.write('\n')

[GPU_d, reg_choose, cell_count] = ReadMain('Suitability/main_reg.1', fig_log )

os.environ['CUDA_VISIBLE_DEVICES'] = str(GPU_d)

df_num = CountDF('Suitability',fig_log)

[cov , cov_without_nodata , df , df_without_nodata , type_count, size, cov_label, df_label] = Sample_change(sample1, sample2, df_num)



if reg_choose == 0:
    RandomForest(sample1, df_without_nodata, cov_without_nodata, df,  type_count, size, fig_log, cell_count)

if reg_choose == 1:
    ANN(sample1, df_without_nodata, cov_without_nodata, df,  type_count, size, fig_log, cell_count)

if reg_choose == 2:
    RandomForest_GPU(sample1, df_without_nodata, cov_without_nodata, df,  type_count, size, fig_log, cell_count)


fig_log.write('Finish at: ')
fig_log.write(str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())))
fig_log.write('\n')