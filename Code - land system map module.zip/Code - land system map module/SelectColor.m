function v = SelectColor (n, band)
% ����������ֵ n ������ǰ�趨�� R, G, B ��ֵ
% n ��1�����֣���ʾ�����������͵ı��

switch n
    case 10
        switch band
            case 'r'
                v = 255;
            case 'g'
                v = 170;
            case 'b'
                v = 0;
        end
        
    case 20
        switch band
            case 'r'
                v = 0;
            case 'g'
                v = 255;
            case 'b'
                v = 197;
        end
        
    case 30
        switch band
            case 'r'
                v = 85;
            case 'g'
                v = 255;
            case 'b'
                v = 0;
        end
        
    case 40
        switch band
            case 'r'
                v = 114;
            case 'g'
                v = 137;
            case 'b'
                v = 68;
        end
        
    case 50
        switch band
            case 'r'
                v = 197;
            case 'g'
                v = 0;
            case 'b'
                v = 255;
        end
        
    case 60
        switch band
            case 'r'
                v = 0;
            case 'g'
                v = 112;
            case 'b'
                v = 255;
        end
        
    case 80
        switch band
            case 'r'
                v = 255;
            case 'g'
                v = 0;
            case 'b'
                v = 0;
        end
        
    case 90
        switch band
            case 'r'
                v = 156;
            case 'g'
                v = 156;
            case 'b'
                v = 156;
        end
    case 100
        switch band
            case 'r'
                v = 0;
            case 'g'
                v = 197;
            case 'b'
                v = 255;
        end
    otherwise
        v = 255;
end

end
